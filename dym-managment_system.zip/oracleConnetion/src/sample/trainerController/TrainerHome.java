package sample.trainerController;

import com.jfoenix.controls.JFXButton;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import sample.DBQueries;
import sample.controller.LoginController;
import sample.controller.UpdateTrainer;
import sample.model.Employee;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TrainerHome {

    @FXML
    private Button logout;
    @FXML
    private JFXButton update;

    @FXML
    private AnchorPane main_Pane;
    private AnchorPane exc;
    private DBQueries dbQueries;
    private Employee employee;

    @FXML
    void initialize(){

        logout.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {


                Parent parent = null;
                try {
                    parent = FXMLLoader.load(getClass().getResource("/sample/view/Login.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Scene scene = new Scene(parent);
                Stage stage = (Stage) logout.getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            }
        });

        update.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                dbQueries = new DBQueries();
                ResultSet resultSet = dbQueries.getTrainer(LoginController.trainerId);

                while(true){
                    try {
                        if (!resultSet.next())
                            break;
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    employee = new Employee();
                    try {
                        employee.setIdNo(resultSet.getLong("trainerId"));
                        employee.setFirstName(resultSet.getString("firstName"));
                        employee.setLastName(resultSet.getString("lastName"));
                        employee.setQualification(resultSet.getString("qualification"));
                        employee.setExperience(resultSet.getString("experience"));
                        employee.setSlotTime(resultSet.getString("timeSlot"));
                        employee.setPassword(resultSet.getString("userPassword"));
                        employee.setName(resultSet.getString("userName"));

                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

                update.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/view/updateTrainer.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));

                UpdateTrainer updateTrainer = loader.getController();
                updateTrainer.userName.setVisible(true);
                updateTrainer.password.setVisible(true);

                updateTrainer.setIdCard(employee.getIdNo());
                updateTrainer.setFirstname(employee.getFirstName());
                updateTrainer.setLastName(employee.getLastName());
                updateTrainer.setExperience(employee.getExperience());
                updateTrainer.setQualfication(employee.getQualification());
                updateTrainer.setTimeSlot(employee.getSlotTime());
                updateTrainer.setUserName(employee.getName());
                updateTrainer.setPassword(employee.getPassword());

                updateTrainer.updateButton.setOnAction(event1 -> {

                    try {
                        dbQueries.updateEmployee(updateTrainer.getIdCard(),
                                updateTrainer.getFirstname(),
                                updateTrainer.getLastName(),
                                updateTrainer.getUserName(),updateTrainer.getPassword(),
                                updateTrainer.getQualfication(),updateTrainer.getExperience()
                                ,updateTrainer.getTimeSlot());
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                    updateTrainer.updateButton.getScene().getWindow().hide();

                });

                stage.showAndWait();
            }
        });
    }
    @FXML
    void checkUsers(ActionEvent event) throws IOException {
        exc = FXMLLoader.load(getClass().getResource("/sample/view/userController.fxml"));
        setNode(exc);
    }

    @FXML
    void exerciseChart(ActionEvent event) throws IOException {
        exc = FXMLLoader.load(getClass().getResource("/sample/view/exerciseChart.fxml"));
        setNode(exc);
    }

    @FXML
    void checkExercise(ActionEvent event) throws IOException {
        exc = FXMLLoader.load(getClass().getResource("/sample/view/allExercises.fxml"));
        setNode(exc);
    }

    public void setNode(Node node)
    {
        main_Pane.getChildren().clear();
        main_Pane.getChildren().add((Node)node);
        AnchorPane.setTopAnchor(node,4.0);
        AnchorPane.setBottomAnchor(node,0.0);
        AnchorPane.setRightAnchor(node,0.0);
        AnchorPane.setLeftAnchor(node,0.0);

        FadeTransition ft =new FadeTransition();
        ft.setDuration(Duration.millis(1500));
        ft.setNode(node);
        ft.setFromValue(0.1);
        ft.setToValue(1);
        ft.setAutoReverse(false);
        ft.play();

    }

}
