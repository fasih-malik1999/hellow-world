package sample.trainerController;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import javafx.stage.Stage;
import sample.DBQueries;
import sample.model.Exercise;
import sample.model.User;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

public class Exercises {

    @FXML
    private TableView<Exercise> table_View;

    @FXML
    private JFXButton updateButton;

    @FXML
    private JFXButton deleteButton;

    private DBQueries dbQueries = new DBQueries();
    private ObservableList<Exercise> exercises ;


    @FXML
    void initialize() throws SQLException, ClassNotFoundException {
        exercises = FXCollections.observableArrayList();
        exercises = ExerciseChartController.exercises;

        TableColumn excId = new TableColumn("ExerciseId");
        TableColumn userId = new TableColumn("UserId");
        TableColumn muscleType = new TableColumn("Muscle Type");
        TableColumn exerciseType = new TableColumn("Exercise Type");

        excId.setPrefWidth(120);
        userId.setPrefWidth(120);
        muscleType.setPrefWidth(120);
        exerciseType.setPrefWidth(120);

        table_View.getColumns().addAll(excId,userId,muscleType,exerciseType);

        setTable(excId,userId,muscleType,exerciseType);

        deleteButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                long id = table_View.getSelectionModel().getSelectedItem().getExId();
                System.out.println(id);
                try {
                    dbQueries.deleteExercise(id);
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
                table_View.refresh();
            }
        });

        updateButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                long id = table_View.getSelectionModel().getSelectedItem().getExId();
                String muscle = table_View.getSelectionModel().getSelectedItem().getMuscleType();
                String exs = table_View.getSelectionModel().getSelectedItem().getExerciseType();
                System.out.println(id);


                updateButton.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/view/updateExercise.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));

                UpdateExercise updateExercise = loader.getController();
                updateExercise.setId(id);
                updateExercise.setMuscle(muscle);
                updateExercise.setExerciseType(exs);

                updateExercise.updateButton.setOnAction(event1 -> {

                    try {
                        dbQueries.updateExercise(id , updateExercise.getExerciseType());
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                    try {
                        setTable(excId,userId,muscleType,exerciseType);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                    updateExercise.updateButton.getScene().getWindow().hide();

                });

                stage.showAndWait();
            }
        });

    }

    public void setTable(TableColumn excid , TableColumn userid, TableColumn muscleType,TableColumn exType) throws SQLException, ClassNotFoundException {

        dbQueries = new DBQueries();
        exercises = FXCollections.observableArrayList();
        ResultSet resultSet = null;
        resultSet = dbQueries.getExercises(ExerciseChartController.userId);

        while (resultSet.next()){

            Exercise exercise = new Exercise();
            try {
                exercise.setExId(resultSet.getInt("excId"));
                exercise.setUserId(resultSet.getInt("userId"));
                exercise.setExerciseType(resultSet.getString("exerciseType"));
                exercise.setMuscleType(resultSet.getString("muscleType"));
            } catch (SQLException e) {
                e.printStackTrace();
            }

            exercises.addAll(exercise);
        }


        excid.setCellValueFactory(new PropertyValueFactory<Exercise,Integer>("exId"));
        userid.setCellValueFactory(new PropertyValueFactory<Exercise,Integer>("userId"));
        muscleType.setCellValueFactory(new PropertyValueFactory<Exercise,String>("muscleType"));
        exType.setCellValueFactory(new PropertyValueFactory<Exercise,String>("exerciseType"));

        table_View.setItems(exercises);
    }
}
