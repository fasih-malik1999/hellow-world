package sample.trainerController;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import sample.DBQueries;
import sample.controller.LoginController;
import sample.model.ExerciseChart;
import sample.model.User;

import java.sql.SQLException;

public class AddExerciseForUser {

    @FXML
    private Label userId;

    @FXML
    private Label trainerId;

    @FXML
    private CheckBox core;

    @FXML
    private CheckBox back;

    @FXML
    private CheckBox lower_limbs;

    @FXML
    private CheckBox upper_limbe;
    @FXML
    private JFXButton addButton;
    private DBQueries dbQueries;

    private ObservableList<String> checkBox = FXCollections.observableArrayList();


    @FXML
    void initialize(){

        userId.setText(String.valueOf(UserController.userId));
        trainerId.setText(String.valueOf(LoginController.trainerId));

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                try {
                    addUser();
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    private void addUser() throws SQLException, ClassNotFoundException {

        if(core.isSelected()){
            checkBox.add(core.getText());}
        if(!core.isSelected()){
            if(checkBox.contains(core.getText())){
                checkBox.remove(core.getText());}
        }
        if(back.isSelected()){
            checkBox.add(back.getText());}
        if(!back.isSelected()){
            if(checkBox.contains(back.getText())){
                checkBox.remove(back.getText());}
        }

        if(upper_limbe.isSelected()){
            checkBox.add(upper_limbe.getText());}
        if(!upper_limbe.isSelected()){
            if(checkBox.contains(upper_limbe.getText())){
                checkBox.remove(upper_limbe.getText());}
        }

        if(lower_limbs.isSelected()){
            checkBox.add(lower_limbs.getText());}
        if(!lower_limbs.isSelected()){
            if(checkBox.contains(lower_limbs.getText())) {
                checkBox.remove(lower_limbs.getText());
            }
        }

        dbQueries = new DBQueries();
        ExerciseChart exerciseChart = new ExerciseChart(UserController.userId,LoginController.trainerId,checkBox.toString());
        for (int i=0 ;i<checkBox.size();i++){
            System.out.println(checkBox.get(i));
        }
        dbQueries.addExercise(exerciseChart , checkBox);
        addButton.getScene().getWindow().hide();

    }
}
