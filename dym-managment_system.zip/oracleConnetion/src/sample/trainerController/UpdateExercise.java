package sample.trainerController;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.scene.text.Text;

public class UpdateExercise {

    @FXML
    private Text userId;

    @FXML
    private Text muscleType;

    @FXML
    private JFXTextField exerciseType;

    @FXML
    public JFXButton updateButton;

    @FXML
    void initialize(){

    }

    public void setId(long id){
        this.userId.setText(String.valueOf(id));
    }
    public void setMuscle(String muscle){
        this.muscleType.setText(muscle);
    }
    public void setExerciseType(String exerciseType){
        this.exerciseType.setText(exerciseType);
    }

    public String getExerciseType(){
        return this.exerciseType.getText();
    }


}
