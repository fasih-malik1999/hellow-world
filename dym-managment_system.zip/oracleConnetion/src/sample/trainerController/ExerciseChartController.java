package sample.trainerController;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import sample.DBQueries;
import sample.controller.LoginController;
import sample.model.Exercise;
import sample.model.ExerciseChart;
import sample.model.User;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ExerciseChartController {

    public static long userId;
    @FXML
    private AnchorPane mani_pane;

    @FXML
    private TableView<ExerciseChart> table_View;

    @FXML
    private JFXButton addButton;


    private DBQueries dbQueries;
    private ObservableList<ExerciseChart> list ;
    public static ObservableList<Exercise> exercises;


    @FXML
    void initialize() {

        TableColumn id = new TableColumn("UserId");
        TableColumn trainerId = new TableColumn("TrainerId");
        TableColumn muscleType = new TableColumn("MuscleType");


        id.setPrefWidth(150);
        trainerId.setPrefWidth(150);
        muscleType.setPrefWidth(150);
        table_View.getColumns().addAll(id,trainerId,muscleType);


        try {
            setTable(id,trainerId,muscleType);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                userId = table_View.getSelectionModel().getSelectedItem().getUserId();
                System.out.println(userId);

            }
        });

    }

    public void setTable(TableColumn userId,TableColumn trainerId,TableColumn muscleType) throws SQLException {


        dbQueries = new DBQueries();
        list = FXCollections.observableArrayList();
        ResultSet resultSet = null;
        try {
            resultSet = dbQueries.getExerciseChart();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        while (resultSet.next()) {
            ExerciseChart chart = new ExerciseChart();
            if(LoginController.timeSlot.equals(resultSet.getString("timeSlot"))) {
                chart.setUserId(resultSet.getInt("userId"));
                chart.setTrainerId(resultSet.getInt("trainerId"));
                chart.setMuscleType(resultSet.getString("muscleType"));
                list.addAll(chart);
            }
        }


        userId.setCellValueFactory(new PropertyValueFactory<User,Integer>("userId"));
        trainerId.setCellValueFactory(new PropertyValueFactory<User,Integer>("trainerId"));
        muscleType.setCellValueFactory(new PropertyValueFactory<User,String>("muscleType"));

        table_View.setItems(list);
    }
}
