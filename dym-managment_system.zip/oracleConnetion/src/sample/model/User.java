package sample.model;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;

public class User extends RecursiveTreeObject<User> {
    private String firstName ,LastName ,Name ,Password , muscle ,timeSlot;
    private long idNo , userAge , userWeight,fee;

    public User(String firstName, String lastName, String name, String password, String muscle, long idNo, long userAge, long userWeight, long fee,String timeSlot) {
        this.firstName = firstName;
        LastName = lastName;
        Name = name;
        Password = password;
        this.muscle = muscle;
        this.idNo = idNo;
        this.userAge = userAge;
        this.userWeight = userWeight;
        this.fee = fee;
        this.timeSlot = timeSlot;
    }

    public User() {
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(String timeSlot) {
        this.timeSlot = timeSlot;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getMuscle() {
        return muscle;
    }

    public void setMuscle(String muscle) {
        this.muscle = muscle;
    }

    public long getIdNo() {
        return idNo;
    }

    public void setIdNo(long idNo) {
        this.idNo = idNo;
    }

    public long getUserAge() {
        return userAge;
    }

    public void setUserAge(long userAge) {
        this.userAge = userAge;
    }

    public long getUserWeight() {
        return userWeight;
    }

    public void setUserWeight(long userWeight) {
        this.userWeight = userWeight;
    }

    public long getFee() {
        return fee;
    }

    public void setFee(long fee) {
        this.fee = fee;
    }

}
