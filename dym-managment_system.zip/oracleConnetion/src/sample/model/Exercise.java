package sample.model;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;

public class Exercise extends RecursiveTreeObject<Exercise> {

    private int exId,userId;
    private String exerciseType , muscleType;

    public Exercise() {
    }

    public Exercise(int exId, int userId, String exerciseType, String muscleType) {
        this.exId = exId;
        this.userId = userId;
        this.exerciseType = exerciseType;
        this.muscleType = muscleType;
    }

    public int getExId() {
        return exId;
    }

    public void setExId(int exId) {
        this.exId = exId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getExerciseType() {
        return exerciseType;
    }

    public void setExerciseType(String exerciseType) {
        this.exerciseType = exerciseType;
    }

    public String getMuscleType() {
        return muscleType;
    }

    public void setMuscleType(String muscleType) {
        this.muscleType = muscleType;
    }
}
