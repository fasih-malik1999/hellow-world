package sample.model;

public class FoodChart {
    private long userId,nutriantId;
    private String food;

    public FoodChart() {
    }

    public FoodChart(long userId, long nutriantId, String food) {
        this.userId = userId;
        this.nutriantId = nutriantId;
        this.food = food;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getNutriantId() {
        return nutriantId;
    }

    public void setNutriantId(long nutriantId) {
        this.nutriantId = nutriantId;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }
}
