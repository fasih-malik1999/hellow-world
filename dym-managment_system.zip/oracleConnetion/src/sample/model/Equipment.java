package sample.model;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.sql.Date;

public class Equipment extends RecursiveTreeObject<Equipment> {

    private int id;
    private String model , name ;
    private ImageView image;
    private long cost;
    private Date dateOfPurchase;
    private Date lastMaintenance;

    public Equipment() {
    }

    public Equipment(int id, String model, String name,  long cost, Date dateOfPurchase, Date lastMaintenance) {
        this.id = id;
        this.model = model;
        this.name = name;
        this.image = image;
        this.cost = cost;
        this.dateOfPurchase = dateOfPurchase;
        this.lastMaintenance = lastMaintenance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ImageView getImage() {
        return image;
    }

    public void setImage(ImageView image) {
        this.image = image;
    }

    public long getCost() {
        return cost;
    }

    public void setCost(long cost) {
        this.cost = cost;
    }

    public Date getDateOfPurchase() {
        return dateOfPurchase;
    }

    public void setDateOfPurchase(Date dateOfPurchase) {
        this.dateOfPurchase = dateOfPurchase;
    }

    public Date getLastMaintenance() {
        return lastMaintenance;
    }

    public void setLastMaintenance(Date lastMaintenance) {
        this.lastMaintenance = lastMaintenance;
    }
}
