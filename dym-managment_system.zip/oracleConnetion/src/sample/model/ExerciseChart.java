package sample.model;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;

public class ExerciseChart extends RecursiveTreeObject<ExerciseChart> {

    private long userId,trainerId;
    private String muscleType;

    public ExerciseChart() {
    }

    public ExerciseChart(long userId, long trainerId, String muscleType) {
        this.userId = userId;
        this.trainerId = trainerId;
        this.muscleType = muscleType;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getTrainerId() {
        return trainerId;
    }

    public void setTrainerId(long trainerId) {
        this.trainerId = trainerId;
    }

    public String getMuscleType() {
        return muscleType;
    }

    public void setMuscleType(String muscleType) {
        this.muscleType = muscleType;
    }
}
