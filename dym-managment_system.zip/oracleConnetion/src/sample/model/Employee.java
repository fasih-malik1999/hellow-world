package sample.model;

import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;

public class Employee extends RecursiveTreeObject<Employee> {

    private String name , password , experience , qualification ,firstName ,lastName;
    private long idNo;
    String slotTime;

    public Employee(String name, String password, String experience, String qualification, String firstName, String lastName,long idNo) {
        this.name = name;
        this.password = password;
        this.experience = experience;
        this.qualification = qualification;
        this.firstName = firstName;
        this.lastName = lastName;
        this.idNo = idNo;
    }

    public Employee() {
    }

    public String getSlotTime() {
        return slotTime;
    }

    public void setSlotTime(String slotTime) {
        this.slotTime = slotTime;
    }

    public long getIdNo() {
        return idNo;
    }

    public void setIdNo(long idNo) {
        this.idNo = idNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
