package sample.usersController;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.DBQueries;
import sample.controller.LoginController;
import sample.model.Exercise;
import sample.model.FoodChart;
import sun.rmi.runtime.Log;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UsersAllExercises {

    @FXML
    private TableView<Exercise> table_view;

    @FXML
    private TableColumn<Exercise, String> muscle;

    @FXML
    private TableColumn<Exercise, String> exercise;

    private DBQueries dbQueries;
    private ObservableList<Exercise> list;

    @FXML
    void initialize() throws SQLException {
        setTable();
    }

    private void setTable() throws SQLException {

        dbQueries =new DBQueries();
        list = FXCollections.observableArrayList();

        ResultSet resultSet = null;
        try {
            resultSet = dbQueries.getExercises(LoginController.userId);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        while (resultSet.next()) {
           Exercise exercise = new Exercise();
           exercise.setMuscleType(resultSet.getString("muscleType"));
           exercise.setExerciseType(resultSet.getString("exerciseType"));

           list.addAll(exercise);
        }

        muscle.setCellValueFactory(new PropertyValueFactory<Exercise,String>("muscleType"));
        exercise.setCellValueFactory(new PropertyValueFactory<Exercise,String>("exerciseType"));

        table_view.setItems(list);
    }


}
