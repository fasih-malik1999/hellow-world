package sample.usersController;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import sample.DBQueries;
import sample.controller.LoginController;
import sample.model.FoodChart;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserAllFood {
    @FXML
    private TableView<FoodChart> table_view;

    @FXML
    private TableColumn<FoodChart, String> food;

    private DBQueries dbQueries;
    private ObservableList<FoodChart> list;

    @FXML
    void initialize() throws SQLException {
        setTable();
    }

    private void setTable() throws SQLException {

        dbQueries =new DBQueries();
        list = FXCollections.observableArrayList();

        ResultSet resultSet = null;
        try {
            resultSet = dbQueries.getUserFood(LoginController.userId);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        while (resultSet.next()) {
            FoodChart foodChart = new FoodChart();
                foodChart.setUserId(resultSet.getLong("userId"));
                foodChart.setNutriantId(resultSet.getLong("nutriantId"));
                foodChart.setFood(resultSet.getString("food"));
                list.addAll(foodChart);
        }

        food.setCellValueFactory(new PropertyValueFactory<FoodChart,String>("food"));

        table_view.setItems(list);
    }

}
