package sample.usersController;

import com.jfoenix.controls.JFXButton;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import sample.DBQueries;
import sample.controller.LoginController;
import sample.model.User;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserHome {

    @FXML
    private JFXButton profile;

    @FXML
    private AnchorPane main_pane;

    @FXML
    private AnchorPane inner_pane;

    @FXML
    private JFXButton logOut;

    private AnchorPane exc;
    private DBQueries dbQueries;
    private User user;
    private long fee;

    @FXML
    void initialize(){

        profile.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                dbQueries = new DBQueries();
                ResultSet resultSet = dbQueries.getUserProfile(LoginController.userId);

                while(true){
                    try {
                        if (!resultSet.next())
                            break;
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    user = new User();
                    try {
                        user.setIdNo(resultSet.getLong("userId"));
                        user.setFirstName(resultSet.getString("firstName"));
                        user.setLastName(resultSet.getString("lastName"));
                        user.setName(resultSet.getString("userName"));
                        user.setPassword(resultSet.getString("userPassword"));
                        user.setUserAge(resultSet.getLong("age"));
                        user.setUserWeight(resultSet.getLong("weight"));
                        fee = resultSet.getLong("fee");
                        user.setMuscle(resultSet.getString("muscleType"));
                        user.setTimeSlot(resultSet.getString("timeSlot"));
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

                profile.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/view/userProfile.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));

                UserProfile userProfile = loader.getController();
                userProfile.setId(user.getIdNo());
                userProfile.setfName(user.getFirstName());
                userProfile.setLname(user.getLastName());
                userProfile.setuName(user.getName());
                userProfile.setPassword(user.getPassword());
                userProfile.setAge(user.getUserAge());
                userProfile.setWeight(user.getUserWeight());
                userProfile.setMuscleType(user.getMuscle());
                userProfile.setTimeSlot(user.getTimeSlot());

                userProfile.update.setOnAction(event1 -> {

                    try {
                        dbQueries.updateUser(userProfile.getId(),userProfile.getfName(),userProfile.getLname()
                                ,userProfile.getuName(),userProfile.getPassword(),userProfile.getAge(),fee,
                                userProfile.getWeight(),userProfile.getMuscleType(),userProfile.getTimeSlot());
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                    userProfile.update.getScene().getWindow().hide();

                });

                stage.showAndWait();
            }
        });
        logOut.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {


                Parent parent = null;
                try {
                    parent = FXMLLoader.load(getClass().getResource("/sample/view/Login.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Scene scene = new Scene(parent);
                Stage stage = (Stage) logOut.getScene().getWindow();
                stage.setScene(scene);
                stage.show();

            }
        });
    }

    @FXML
    void checkExercise(ActionEvent event) throws IOException {
        exc = FXMLLoader.load(getClass().getResource("/sample/view/allExercisesUser.fxml"));
        setNode(exc);
    }

    @FXML
    void checkFood(ActionEvent event) throws IOException {
        exc = FXMLLoader.load(getClass().getResource("/sample/view/userAllFood.fxml"));
        setNode(exc);
    }

    public void setNode(Node node)
    {
        inner_pane.getChildren().clear();
        inner_pane.getChildren().add((Node)node);
        AnchorPane.setTopAnchor(node,4.0);
        AnchorPane.setBottomAnchor(node,0.0);
        AnchorPane.setRightAnchor(node,0.0);
        AnchorPane.setLeftAnchor(node,0.0);

        FadeTransition ft =new FadeTransition();
        ft.setDuration(Duration.millis(1500));
        ft.setNode(node);
        ft.setFromValue(0.1);
        ft.setToValue(1);
        ft.setAutoReverse(false);
        ft.play();

    }


}
