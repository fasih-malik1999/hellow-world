package sample.usersController;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class UserProfile {

    @FXML
    private JFXTextField fName;

    @FXML
    private JFXTextField lname;

    @FXML
    private JFXTextField uName;

    @FXML
    private JFXTextField password;

    @FXML
    private JFXTextField age;

    @FXML
    private JFXTextField weight;

    @FXML
    private JFXTextField id;

    @FXML
    private JFXTextField muscleType;

    @FXML
    private JFXTextField timeSlot;

    @FXML
    public JFXButton update;

    @FXML
    public Label feeLabel;

    @FXML
    public JFXTextField fee;

    public long getFee() {
        return Long.parseLong(this.fee.getText());
    }

    public void setFee(long fee) {
        this.fee.setText(String.valueOf(fee));
    }


    public String getfName() {
        return this.fName.getText();
    }

    public void setfName(String fName) {
        this.fName.setText(fName);
    }

    public String getLname() {
        return this.lname.getText();
    }

    public void setLname(String lname) {
        this.lname.setText(lname);
    }

    public String getuName() {
        return this.uName.getText();
    }

    public void setuName(String uName) {
        this.uName.setText(uName);
    }

    public String getPassword() {
        return this.password.getText();
    }

    public void setPassword(String password) {
        this.password.setText(password);
    }

    public long getAge() {
        return Long.parseLong(this.age.getText());
    }

    public void setAge(long age) {
        this.age.setText(String.valueOf(age));
    }

    public long getWeight() {
        return Long.parseLong(this.weight.getText());
    }

    public void setWeight(long weight) {
        this.weight.setText(String.valueOf(weight));
    }

    public long getId() {
        return Long.parseLong(this.id.getText());
    }

    public void setId(long id) {
        this.id.setText(String.valueOf(id));
    }

    public String getMuscleType() {
        return this.muscleType.getText();
    }

    public void setMuscleType(String muscleType) {
        this.muscleType.setText(muscleType);
    }

    public String getTimeSlot() {
        return this.timeSlot.getText();
    }

    public void setTimeSlot(String timeSlot) {
        this.timeSlot.setText(timeSlot);
    }
}
