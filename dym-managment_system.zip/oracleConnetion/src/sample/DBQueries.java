package sample;

import javafx.collections.ObservableList;
import sample.controller.LoginController;
import sample.model.*;
import java.io.File;
import java.io.FileInputStream;
import java.sql.*;

public class DBQueries {

    Connection dbConnection;

    public Connection getDbConnection() throws ClassNotFoundException, SQLException {


//step1 load the driver class
            Class.forName ("oracle.jdbc.OracleDriver");

//step2 create  the connection object
             dbConnection= DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:orcl","SYSTEM","multansultan8");

             return dbConnection;
    }

    public void signUpEmployee(Employee employee,String value) {


        String tableName= "AdminT";
        String id ="adminId";

         if(value.equals("Admin")){
            tableName = "AdminT";
            id = "adminId";
        }else if(value.equals("Trainer")){
            tableName = "TrainerT";
            id = "trainerId";
        }else if(value.equals("Nutriant")){
            tableName = "NutriantT";
            id = "nutriantId";
        }

        String insert;

         if(tableName.equals("TrainerT")) {
             insert = "INSERT INTO " + tableName + " ( " + id + " , " +
                     "firstName, lastName, userName , userPassword, " +
                     "qualification , experience,timeSlot) VALUES(?,?,?,?,?,?,?,?)";

         }else if(tableName.equals("NutriantT")){
             insert = "INSERT INTO " + tableName + " ( " + id + " , " +
                     "firstName, lastName, userName , userPassword, " +
                     "qualification , experience,timeSlot) VALUES(?,?,?,?,?,?,?,?)";
         }else {
            insert = "INSERT INTO " + tableName + " ( " + id + " , " +
                    "firstName, lastName, userName , userPassword, " +
                    "qualification , experience) VALUES(?,?,?,?,?,?,?)";
        }


        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(insert);

            preparedStatement.setLong(1, employee.getIdNo());
            preparedStatement.setString(2, employee.getFirstName());
            preparedStatement.setString(3, employee.getLastName());
            preparedStatement.setString(4, employee.getName());
            preparedStatement.setString(5, employee.getPassword());
            preparedStatement.setString(6, employee.getQualification());
            preparedStatement.setString(7, employee.getExperience());
            if(tableName.equals("TrainerT") || tableName.equals("NutriantT")){
                preparedStatement.setString(8,employee.getSlotTime());
            }

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    public ResultSet getEmployee(Employee employee , String value) {
        ResultSet resultSet = null;

        String tableName= "AdminT";
//        if(value.equals("User")){
//            tableName = "UserT";
//        }else
        if(value.equals("Admin")){
            tableName = "AdminT";
        }else if(value.equals("Trainer")){
            tableName = "TrainerT";
        }else if(value.equals("Nutriant")){
            tableName = "NutriantT";
        }

        if (!employee.getName().equals("") || !employee.getPassword().equals("")) {
            String query = "SELECT * FROM " + tableName + " WHERE "
                    +  "userName=?" + " AND " + "userPassword=?";

            // select all from users where username="paulo" and password="password"

            try {
                PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
                preparedStatement.setString(1, employee.getName());
                preparedStatement.setString(2, employee.getPassword());

                resultSet = preparedStatement.executeQuery();

            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

        } else {
            System.out.println("Please enter your credentials");
        }
        return resultSet;
    }

    public void signUpUser(User user) throws SQLException, ClassNotFoundException {

        CallableStatement insert = getDbConnection().prepareCall("{ call PROCEDURE2(?,?,?,?,?,?,?,?,?,?) }");
        insert.setLong(1, user.getIdNo());
        insert.setString(2, user.getFirstName());
        insert.setString(3, user.getLastName());
        insert.setString(4, user.getName());
        insert.setString(5, user.getPassword());
        insert.setLong(6, user.getUserAge());
        insert.setLong(7, user.getUserWeight());
        insert.setLong(8, user.getFee());
        insert.setString(9, user.getMuscle());
        insert.setString(10,user.getTimeSlot());
        insert.executeUpdate();

    }
    public ResultSet getUser(User user) {
        ResultSet resultSet = null;

        if (!user.getName().equals("") || !user.getPassword().equals("")) {
            String query = "SELECT * FROM  UserT WHERE "
                    +  "userName=?" + " AND " + "userPassword=?";

            try {
                PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
                preparedStatement.setString(1, user.getName());
                preparedStatement.setString(2, user.getPassword());

                resultSet = preparedStatement.executeQuery();


            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }


        } else {
            System.out.println("Please enter your credentials");

        }


        return resultSet;
    }
    public ResultSet getAllUsers() throws SQLException, ClassNotFoundException {

        String query = "SELECT * FROM  UserT";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet;

    }
    public void deleteUser(long usrId) throws SQLException, ClassNotFoundException {

        String query1 = "DELETE FROM ExerciseChart  WHERE userId=?";

        PreparedStatement ps = getDbConnection().prepareStatement(query1);
        ps.setLong(1, usrId);
        ps.execute();
        ps.close();


        String query2 = "DELETE FROM FoodChart  WHERE userId=?";

        PreparedStatement ps1 = getDbConnection().prepareStatement(query2);
        ps1.setLong(1, usrId);
        ps1.execute();
        ps1.close();

        String query3 = "DELETE FROM ExerciseT  WHERE userId=?";

        PreparedStatement ps2 = getDbConnection().prepareStatement(query3);
        ps2.setLong(1, usrId);
        ps2.execute();
        ps2.close();

        String query = "DELETE FROM UserT  WHERE userId=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setLong(1, usrId);
        preparedStatement.execute();
        preparedStatement.close();


    }


    public void addEquipment(Equipment equipment , FileInputStream fis , File file){

        String query = "INSERT INTO EquipT ( equId , image ," +
                " equName, equModel , equCast ," +
                " dateOfPurchase , dateOfMaintance )" +
                "VALUES(?,?,?,?,?,?,?)";

        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

            preparedStatement.setInt(1,equipment.getId());
           // preparedStatement.setString(2,equipment.getImage());
            preparedStatement.setBinaryStream(2,fis,(int) file.length());
            preparedStatement.setString(3,equipment.getName());
            preparedStatement.setString(4,equipment.getModel());
            preparedStatement.setLong(5,equipment.getCost());
            preparedStatement.setDate(6,  equipment.getDateOfPurchase());
            preparedStatement.setDate(7, equipment.getLastMaintenance());


            preparedStatement.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }
    public ResultSet getEquipment() throws SQLException,ClassNotFoundException{

        String query = "SELECT * FROM  EquipT";
        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        ResultSet resultSet = preparedStatement.executeQuery();
        return resultSet;
    }
    public void deleteEqu(long id)throws SQLException,ClassNotFoundException{
        String query = "DELETE FROM EquipT  WHERE equId=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setLong(1, id);
        preparedStatement.execute();
        preparedStatement.close();

    }


    public ResultSet getAllTrainers() throws SQLException, ClassNotFoundException {

        String query = "SELECT * FROM  TrainerT";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet;

    }
    public void deleteTrainer(long trainerId) throws SQLException, ClassNotFoundException {

        String query1 = "DELETE FROM ExerciseChart  WHERE trainerId=?";

        PreparedStatement ps = getDbConnection().prepareStatement(query1);
        ps.setLong(1, trainerId);
        ps.execute();
        ps.close();

        String query = "DELETE FROM TrainerT  WHERE trainerId=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setLong(1, trainerId);
        preparedStatement.execute();
        preparedStatement.close();
    }

    public ResultSet getAllNutriants() throws SQLException, ClassNotFoundException {

        String query = "SELECT * FROM  NutriantT";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet;

    }
    public void deleteNutriant(long nutriantId) throws SQLException, ClassNotFoundException {

        String query2 = "DELETE FROM FoodChart  WHERE nutriantId=?";

        PreparedStatement ps1 = getDbConnection().prepareStatement(query2);
        ps1.setLong(1, nutriantId);
        ps1.execute();
        ps1.close();

        String query = "DELETE FROM NutriantT  WHERE nutriantId=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setLong(1, nutriantId);
        preparedStatement.execute();
        preparedStatement.close();
    }

    public ResultSet getExerciseChart() throws SQLException, ClassNotFoundException {

        String query = "SELECT * FROM  ExerciseChart";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet;

    }

    public String[] coreList = {"Hanging les circles","Trunk twist","Barbell overhead sit ups"};
    public String[] backList = {"Dead lift","wide grip pulles","Tbar row","Single arm dumbell row"};
    public String[] upperList = {"Plank row","Ball pushes","Bicep and Tricep"};
    public String[] lowerList = {"Running","Leg press","Hamstring curls","Barbell bench press","Seated machine chest press"};

    public void addExercise(ExerciseChart exerciseChart , ObservableList<String> list) throws SQLException, ClassNotFoundException {

        String query = "INSERT INTO ExerciseChart ( userId , trainerId , muscleType,timeSlot)" +
                "VALUES(?,?,?,?)";

        try{

            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

            preparedStatement.setLong(1,exerciseChart.getUserId());
            preparedStatement.setLong(2,exerciseChart.getTrainerId());
            preparedStatement.setString(3,exerciseChart.getMuscleType());
            preparedStatement.setString(4, LoginController.timeSlot);

            preparedStatement.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        for(int i=0 ; i<list.size() ; i++){
            System.out.println(list.get(i));
            System.out.println(list.size());


                if(list.get(i).equals("Core")){

                    for(int j=0 ; j<3;j++){

                        String q1 = "INSERT INTO ExerciseT (muscleType , exerciseType,userId)" +
                                "VALUES(?,?,?)";
                        PreparedStatement preparedStatement = getDbConnection().prepareStatement(q1);
                        //preparedStatement.setLong(1,(j+10+exerciseChart.getUserId()));
                        preparedStatement.setString(1,"Core");
                        preparedStatement.setString(2,coreList[j]);
                        preparedStatement.setLong(3,exerciseChart.getUserId());

                        preparedStatement.execute();

                    }
                }else if(list.get(i).equals("Back")) {


                    for (int k = 0; k < 4; k++) {

                        String q2 = "INSERT INTO ExerciseT ( excId , muscleType , exerciseType,userId)" +
                                "VALUES(?,?,?,?)";
                        PreparedStatement p1 = getDbConnection().prepareStatement(q2);
                        p1.setLong(1, (k + 20+exerciseChart.getUserId()));
                        p1.setString(2, "Back");
                        p1.setString(3, backList[k]);
                        p1.setLong(4, exerciseChart.getUserId());

                        p1.execute();

                    }
                }else if(list.get(i).equals("Upper limbs")) {


                    for (int l = 0; l < 3; l++) {

                        String q3 = "INSERT INTO ExerciseT ( excId , muscleType , exerciseType,userId)" +
                                "VALUES(?,?,?,?)";
                        PreparedStatement p2 = getDbConnection().prepareStatement(q3);
                        p2.setLong(1, (l + 30+exerciseChart.getUserId()));
                        p2.setString(2, "Upper limbs");
                        p2.setString(3, upperList[l]);
                        p2.setLong(4, exerciseChart.getUserId());

                        p2.execute();

                    }
                }else if(list.get(i).equals("Lower limbs")) {

                    for (int m = 0; m < 5; m++) {

                        String q2 = "INSERT INTO ExerciseT ( excId , muscleType , exerciseType,userId)" +
                                "VALUES(?,?,?,?)";
                        PreparedStatement p1 = getDbConnection().prepareStatement(q2);
                        p1.setLong(1, (m + 40+exerciseChart.getUserId()));
                        p1.setString(2, "Lower limbs");
                        p1.setString(3, lowerList[m]);
                        p1.setLong(4, exerciseChart.getUserId());

                        p1.execute();

                    }
                }

        }


    }
    public ResultSet getExercises(long userId) throws SQLException, ClassNotFoundException {

        String query = "SELECT * FROM  ExerciseT WHERE userId=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setLong(1,userId);

        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet;

    }
    public void deleteExercise(long exId) throws SQLException, ClassNotFoundException {
        String query = "DELETE FROM ExerciseT  WHERE excId=?";

        System.out.println("db"+exId);
        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setLong(1, exId);
        preparedStatement.execute();
        preparedStatement.close();
    }
    public void updateExercise(long id, String exerciseTyp) throws SQLException, ClassNotFoundException {
        String query = "UPDATE ExerciseT SET exerciseType=? WHERE excid=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setString(1, exerciseTyp);
        preparedStatement.setLong(2, id);
        preparedStatement.executeUpdate();
        preparedStatement.close();

    }

    public void addFood(FoodChart foodChart){
        String query = "INSERT INTO FoodChart ( userId , nutriantId , food ,timeSlot )" +
                "VALUES(?,?,?,?)";
        try{
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

            preparedStatement.setLong(1,foodChart.getUserId());
            preparedStatement.setLong(2,foodChart.getNutriantId());
            preparedStatement.setString(3,foodChart.getFood());
            preparedStatement.setString(4, LoginController.timeSlot);

            preparedStatement.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    public ResultSet getFood(String slot) throws SQLException, ClassNotFoundException {

        String query = "SELECT * FROM  FoodChart WHERE timeSlot=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setString(1,slot);

        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet;

    }

    public ResultSet getUserFood(long userId) throws SQLException, ClassNotFoundException {
        String query = "SELECT * FROM  FoodChart WHERE userId=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setLong(1,userId);

        ResultSet resultSet = preparedStatement.executeQuery();

        return resultSet;

    }

    public ResultSet getUserProfile(long id) {
        ResultSet resultSet = null;

            String query = "SELECT * FROM  UserT WHERE "
                    +  "userId=?";

            try {
                PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
                preparedStatement.setLong(1, id);

                resultSet = preparedStatement.executeQuery();

            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

        return resultSet;
    }

    public void updateUser(long id, String fnm , String lnm , String unm , String password ,long age, long fee,long weight,String muscle,String time) throws SQLException, ClassNotFoundException {
        String query = "UPDATE UserT SET userId=?" +
                " ,firstName=?, lastName=?, userName=? , " +
                "userPassword=?, age=? , weight=? , fee=? , muscleType=? , timeSlot=?" +
                " WHERE userId=?";

        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

            preparedStatement.setLong(1, id);
            preparedStatement.setString(2, fnm);
            preparedStatement.setString(3, lnm);
            preparedStatement.setString(4, unm);
            preparedStatement.setString(5, password);
            preparedStatement.setLong(6, age);
            preparedStatement.setLong(7, weight);
            preparedStatement.setLong(8, fee);
            preparedStatement.setString(9, muscle);
            preparedStatement.setString(10,time);
            preparedStatement.setLong(11, id);

            preparedStatement.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

    public void deleteFood(long id) throws SQLException, ClassNotFoundException {
        String query = "DELETE FROM FoodChart  WHERE userId=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setLong(1, id);
        preparedStatement.execute();
        preparedStatement.close();
    }

    public void updateFood(long id, String food) throws SQLException, ClassNotFoundException {
        String query = "UPDATE FoodChart SET food=? WHERE userId=?";

        PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
        preparedStatement.setString(1, food);
        preparedStatement.setLong(2, id);
        preparedStatement.executeUpdate();
        preparedStatement.close();

    }


    public ResultSet getTrainer(long id) {
        ResultSet resultSet = null;

        String query = "SELECT * FROM  TrainerT WHERE "
                +  "trainerId=?";

        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
            preparedStatement.setLong(1, id);

            resultSet = preparedStatement.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return resultSet;
    }
    public void updateEmployee(long id,String fnm,String lnm,String nm,String password,String qual,String exp,String tms) throws SQLException, ClassNotFoundException {
        String query = "UPDATE TrainerT SET trainerId=?" +
                " ,firstName=?, lastName=?, userName=? , " +
                "userPassword=?, qualification=? , experience=? , timeSlot=?" +
                " WHERE trainerId=?";

        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

            preparedStatement.setLong(1, id);
            preparedStatement.setString(2, fnm);
            preparedStatement.setString(3, lnm);
            preparedStatement.setString(4, nm);
            preparedStatement.setString(5, password);
            preparedStatement.setString(6,qual);
            preparedStatement.setString(7,exp);
            preparedStatement.setString(8,tms);
            preparedStatement.setLong(9, id);

            preparedStatement.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

    public ResultSet getNutriant(long id) {
        ResultSet resultSet = null;

        String query = "SELECT * FROM  NutriantT WHERE "
                +  "nutriantId=?";

        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);
            preparedStatement.setLong(1, id);

            resultSet = preparedStatement.executeQuery();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return resultSet;
    }
    public void updateEmployee2(long id,String fnm,String lnm,String nm,String password,String qual,String exp,String tms) throws SQLException, ClassNotFoundException {
        String query = "UPDATE NutriantT SET nutriantId=?" +
                " ,firstName=?, lastName=?, userName=? , " +
                "userPassword=?, qualification=? , experience=? , timeSlot=?" +
                " WHERE nutriantId=?";

        try {
            PreparedStatement preparedStatement = getDbConnection().prepareStatement(query);

            preparedStatement.setLong(1, id);
            preparedStatement.setString(2, fnm);
            preparedStatement.setString(3, lnm);
            preparedStatement.setString(4, nm);
            preparedStatement.setString(5, password);
            preparedStatement.setString(6,qual);
            preparedStatement.setString(7,exp);
            preparedStatement.setString(8,tms);
            preparedStatement.setLong(9, id);

            preparedStatement.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }
}
