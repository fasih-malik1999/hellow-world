package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import sample.animations.FadeTransition;

import java.io.IOException;

public class Splash {


    @FXML
    private AnchorPane parent;

    @FXML
    public void initialize() {
       // makeStageDrageable();
        FadeTransition.applyFadeTransition(parent, Duration.seconds(2), (e) -> {

                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/view/login.fxml"));

            try {
                loader.load();
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            System.out.println("user");
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
            stage.setResizable(false);
            parent.getScene().getWindow().hide();
           // stage.showAndWait();

        });
    }

}
