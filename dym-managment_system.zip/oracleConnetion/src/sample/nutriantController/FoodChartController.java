package sample.nutriantController;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import sample.DBQueries;
import sample.controller.LoginController;
import sample.model.FoodChart;
import sample.model.User;
import sample.trainerController.UpdateExercise;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FoodChartController {

    @FXML
    private TableView<FoodChart> table_view;

    @FXML
    private TableColumn<FoodChart,Long> userId;

    @FXML
    private TableColumn<FoodChart, Long> nutriantId;

    @FXML
    private TableColumn<FoodChart, String > food;

    @FXML
    private JFXButton update;

    @FXML
    private JFXButton delete;

    private DBQueries dbQueries;
    private ObservableList<FoodChart> list;

    @FXML
    void initialize() throws SQLException {
        setTable();

        delete.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event) {

                long id  = table_view.getSelectionModel().getSelectedItem().getUserId();
                table_view.getItems().remove(table_view.getSelectionModel().getSelectedItem());

                try {
                    dbQueries.deleteFood(id);
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
                table_view.refresh();
            }
        });
        update.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                long id  = table_view.getSelectionModel().getSelectedItem().getUserId();
                String food = table_view.getSelectionModel().getSelectedItem().getFood();

                update.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/view/updateFood.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));

                UpdateFood updateFood = loader.getController();
                updateFood.setUserId(id);
                updateFood.setFood(food);

                updateFood.updateButton.setOnAction(event1 -> {

                    try {
                        dbQueries.updateFood(id , updateFood.getFood());
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                    try {
                        setTable();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }

                    updateFood.updateButton.getScene().getWindow().hide();

                });

                stage.showAndWait();


            }
        });
    }

    private void setTable() throws SQLException {

        dbQueries =new DBQueries();
        list = FXCollections.observableArrayList();

        ResultSet resultSet = null;
        try {
            resultSet = dbQueries.getFood(LoginController.timeSlot);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        while (resultSet.next()) {
           FoodChart foodChart = new FoodChart();
            if (LoginController.timeSlot.equals(resultSet.getString("timeSlot"))) {
               foodChart.setUserId(resultSet.getLong("userId"));
               foodChart.setNutriantId(resultSet.getLong("nutriantId"));
               foodChart.setFood(resultSet.getString("food"));
                list.addAll(foodChart);
            }
        }

        userId.setCellValueFactory(new PropertyValueFactory<FoodChart,Long>("userId"));
        nutriantId.setCellValueFactory(new PropertyValueFactory<FoodChart,Long>("nutriantId"));
        food.setCellValueFactory(new PropertyValueFactory<FoodChart,String>("food"));

        table_view.setItems(list);
    }
}
