package sample.nutriantController;

import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TreeItem;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import sample.DBQueries;
import sample.controller.LoginController;
import sample.model.User;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class controllUser {

    @FXML
    private TableView<User> table_view;

    @FXML
    private TableColumn<User, Long> id;

    @FXML
    private TableColumn<User, String> firstName;

    @FXML
    private TableColumn<User, String> lastName;

    @FXML
    private TableColumn<User, Long> age;

    @FXML
    private TableColumn<User , Long> weight;


    @FXML
    private JFXButton addButton;

    private ObservableList<User> list;
    private DBQueries dbQueries;
    public static long userId;

    @FXML
    void initialize() throws SQLException {
        setTable();

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                User selectedItem = table_view.getSelectionModel().getSelectedItem();
                 //table_view.getSelectionModel().getSelectedItem().getParent().getChildren().remove(selectedItem);
                userId = selectedItem.getIdNo();
                System.out.println(userId);

                FXMLLoader loader = new FXMLLoader();

                loader.setLocation(getClass().getResource("/sample/view/addFood.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.showAndWait();
            }
        });

    }


    private void setTable() throws SQLException {

        dbQueries =new DBQueries();
        list = FXCollections.observableArrayList();

        ResultSet resultSet = null;
        try {
            resultSet = dbQueries.getAllUsers();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        while (resultSet.next()) {
            User user = new User();
            if (LoginController.timeSlot.equals(resultSet.getString("timeSlot"))) {
                user.setIdNo(resultSet.getLong("userId"));
                user.setFirstName(resultSet.getString("firstName"));
                user.setLastName(resultSet.getString("lastName"));
                user.setUserAge(resultSet.getLong("age"));
                user.setUserWeight(resultSet.getLong("weight"));
                user.setFee(resultSet.getLong("fee"));
                user.setMuscle(resultSet.getString("muscleType"));
                user.setTimeSlot(resultSet.getString("timeSlot"));
                list.addAll(user);
            }
        }

        id.setCellValueFactory(new PropertyValueFactory<User,Long>("idNo"));
        firstName.setCellValueFactory(new PropertyValueFactory<User,String>("firstName"));
        lastName.setCellValueFactory(new PropertyValueFactory<User,String>("LastName"));
        age.setCellValueFactory(new PropertyValueFactory<User,Long>("userAge"));
        weight.setCellValueFactory(new PropertyValueFactory<User,Long>("userWeight"));

        table_view.setItems(list);

    }


}
