package sample.nutriantController;

import com.jfoenix.controls.JFXButton;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;

public class UpdateFood {

    @FXML
    private Text userId;

    @FXML
    private TextArea food;

    @FXML
    public JFXButton updateButton;


    public void setUserId(long userId) {
        this.userId.setText(String.valueOf(userId));
    }

    public String getFood() {
        return this.food.getText();
    }

    public void setFood(String food) {
        this.food.setText(food);
    }
}
