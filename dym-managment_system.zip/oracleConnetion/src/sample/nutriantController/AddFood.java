package sample.nutriantController;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;
import sample.DBQueries;
import sample.controller.LoginController;
import sample.model.FoodChart;

public class AddFood {

    @FXML
    private Text userId;

    @FXML
    private Text nutriantId;

    @FXML
    private TextArea textArea;

    @FXML
    private JFXButton addButton;
    private DBQueries dbQueries;

    @FXML
    void initialize(){

        userId.setText(String.valueOf(controllUser.userId));
        nutriantId.setText(String.valueOf(LoginController.nutriantId));

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                addFood();
            }
        });
    }

    private void addFood() {
        dbQueries = new DBQueries();
        FoodChart chart = new FoodChart(controllUser.userId,LoginController.nutriantId,textArea.getText());
        dbQueries.addFood(chart);
        addButton.getScene().getWindow().hide();
    }
}
