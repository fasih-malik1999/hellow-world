package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.IntegerBinding;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import sample.DBQueries;
import sample.model.User;

import java.sql.SQLException;

public class Addnewuser {


    @FXML
    private JFXTextField firstName;

    @FXML
    private JFXTextField lastname;

    @FXML
    private JFXTextField name;

    @FXML
    private JFXTextField age;

    @FXML
    private JFXTextField weight;

    @FXML
    private JFXPasswordField password;

    @FXML
    private JFXButton addUser;

    @FXML
    private JFXTextField idCard;

    private String fnm ,lnm ,nm ,pas ;
    // private String userAge , userWeight;
    private DBQueries dbQueries;
    private long idNo , userAge , userWeight;

    @FXML
    private CheckBox ch1;

    @FXML
    private CheckBox ch2;

    @FXML
    private CheckBox ch3;

    @FXML
    private CheckBox ch4;

    @FXML
    private RadioButton dayTime;

    @FXML
    private RadioButton nightTime;

    private String muscle="";
    private int no = 0;
    private long fee;
    private String s="";

    private ObservableList<String> checkBox = FXCollections.observableArrayList();


    @FXML
    void initialize()
    {

        addUser.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    addUser();
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });


        ToggleGroup tg = new ToggleGroup();
        dayTime.setToggleGroup(tg);
        nightTime.setToggleGroup(tg);

        // add a change listener
        tg.selectedToggleProperty().addListener(new ChangeListener<Toggle>()
        {
            public void changed(ObservableValue<? extends Toggle> ob,
                                Toggle o, Toggle n)
            {

                RadioButton rb = (RadioButton)tg.getSelectedToggle();

                if (rb != null) {
                    s = rb.getText();
                    System.out.println(s);
                }
            }
        });
    }


    private void addUser() throws SQLException, ClassNotFoundException {

        dbQueries = new DBQueries();

        fnm = firstName.getText();
        lnm = lastname.getText();
        nm =  name.getText();
        pas = password.getText();
        userAge = Long.parseLong(age.getText());
        userWeight = Long.parseLong(weight.getText());
        idNo = Long.parseLong(idCard.getText());

        if(ch1.isSelected()){
            checkBox.add(ch1.getText());}
        if(!ch1.isSelected()){
            if(checkBox.contains(ch1.getText())){
                checkBox.remove(ch1.getText());}
        }
        if(ch2.isSelected()){
            checkBox.add(ch2.getText());}
        if(!ch2.isSelected()){
            if(checkBox.contains(ch2.getText())){
                checkBox.remove(ch2.getText());}
        }

        if(ch3.isSelected()){
            checkBox.add(ch3.getText());}
        if(!ch3.isSelected()){
            if(checkBox.contains(ch3.getText())){
                checkBox.remove(ch3.getText());}
        }

        if(ch4.isSelected()){
            checkBox.add(ch4.getText());}
        if(!ch4.isSelected()){
            if(checkBox.contains(ch4.getText())) {
                checkBox.remove(ch4.getText());
            }
        }

        fee = checkBox.size() * 1000;
//
//        for(int i=0 ;i<checkBox.size();i++){
//            System.out.println(checkBox.get(i));
//        }

        User user = new User(fnm,lnm,nm,pas,checkBox.toString(),idNo,userAge,userWeight,fee,s);
        dbQueries.signUpUser(user);
        addUser.getScene().getWindow().hide();


    }


}