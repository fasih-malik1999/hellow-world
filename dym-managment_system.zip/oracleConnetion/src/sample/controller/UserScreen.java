package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import sample.DBQueries;
import sample.model.User;
import sample.usersController.UserProfile;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.Predicate;

public class UserScreen {

    @FXML
    private TableView<User> tableview;
    private ObservableList<User> userList;
    private DBQueries dbQueries;

    @FXML
    private JFXButton addButton;

    @FXML
    private JFXButton updateButton;

    @FXML
    private JFXButton deleteButton;


    @FXML
    private TextField search;
    private User user;
    @FXML
    void initialize() throws SQLException {

        TableColumn id = new TableColumn("UserId");
        TableColumn firstName = new TableColumn("FirstName");
        TableColumn lastName = new TableColumn("LastName");
        TableColumn age = new TableColumn("Age");
        TableColumn weight = new TableColumn("Weight");
        TableColumn muscle = new TableColumn("Muscle");
        TableColumn fee = new TableColumn("Fee");
        TableColumn timeSlot = new TableColumn("TimeSlot");

        id.setPrefWidth(90);
        firstName.setPrefWidth(90);
        lastName.setPrefWidth(90);
        age.setPrefWidth(90);
        weight.setPrefWidth(90);
        muscle.setPrefWidth(220);
        fee.setPrefWidth(90);


        tableview.getColumns().addAll(id,firstName,lastName,age,weight,muscle,fee,timeSlot);
        setTable(id,firstName,lastName,age,weight,muscle,fee,timeSlot);

        FilteredList<User> users = new FilteredList<>(userList);
        search.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                users.setPredicate(new Predicate<User>() {
                    @Override
                    public boolean test(User user) {
                      if(newValue == null || newValue.isEmpty()){
                          return true;
                      }

                      String lower = newValue.toLowerCase();
                      if(user.getFirstName().toLowerCase().indexOf(lower) != -1){
                          return true;
                      }else if(user.getLastName().toLowerCase().indexOf(lower) != -1){
                          return true;
                      }
                      else
                          return false;
                    }
                });
            }
        });

        tableview.setItems(users);


        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                addButton.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/view/addnewUser.fxml"));
                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.showAndWait();

               // tableview.refresh();
                try {
                    setTable(id,firstName,lastName,age,weight,muscle,fee,timeSlot);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
        updateButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                long idd = tableview.getSelectionModel().getSelectedItem().getIdNo();
                dbQueries = new DBQueries();
                ResultSet resultSet = dbQueries.getUserProfile(idd);
                System.out.println(idd);

                while(true){
                    try {
                        if (!resultSet.next())
                            break;
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    user = new User();
                    try {
                        user.setIdNo(resultSet.getLong("userId"));
                        user.setFirstName(resultSet.getString("firstName"));
                        user.setLastName(resultSet.getString("lastName"));
                        user.setName(resultSet.getString("userName"));
                        user.setPassword(resultSet.getString("userPassword"));
                        user.setUserAge(resultSet.getLong("age"));
                        user.setUserWeight(resultSet.getLong("weight"));
                        user.setFee(resultSet.getLong("fee"));
                        user.setMuscle(resultSet.getString("muscleType"));
                        user.setTimeSlot(resultSet.getString("timeSlot"));
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

                updateButton.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/view/userProfile.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));

                UserProfile userProfile = loader.getController();
                userProfile.feeLabel.setVisible(true);
                userProfile.fee.setVisible(true);
                userProfile.setId(user.getIdNo());
                userProfile.setfName(user.getFirstName());
                userProfile.setLname(user.getLastName());
                userProfile.setuName(user.getName());
                userProfile.setPassword(user.getPassword());
                userProfile.setAge(user.getUserAge());
                userProfile.setWeight(user.getUserWeight());
                userProfile.setMuscleType(user.getMuscle());
                userProfile.setTimeSlot(user.getTimeSlot());
                userProfile.setFee(user.getFee());

                userProfile.update.setOnAction(event1 -> {

                    try {
                        dbQueries.updateUser(userProfile.getId(),userProfile.getfName(),userProfile.getLname()
                                ,userProfile.getuName(),userProfile.getPassword(),userProfile.getAge(),userProfile.getFee(),
                                userProfile.getWeight(),userProfile.getMuscleType(),userProfile.getTimeSlot());
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                    try {
                        setTable(id,firstName,lastName,age,weight,muscle,fee,timeSlot);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }

                    userProfile.update.getScene().getWindow().hide();
                });
                stage.showAndWait();
            }
        });
        deleteButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                long idd = tableview.getSelectionModel().getSelectedItem().getIdNo();
              //  tableview.getItems().remove(tableview.getSelectionModel().getSelectedItem());
                System.out.println(idd);
                try {
                    dbQueries.deleteUser(idd);
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }

                try {
                    setTable(id,firstName,lastName,age,weight,muscle,fee,timeSlot);
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                // tableview.refresh();
            }
        });
    }

    public void setTable(TableColumn id,TableColumn firstName,TableColumn lastName,TableColumn age,TableColumn weight , TableColumn muscle,TableColumn fee,TableColumn timeSlot) throws SQLException{


        dbQueries = new DBQueries();
        userList = FXCollections.observableArrayList();
        ResultSet resultSet = null;
        try {
            resultSet = dbQueries.getAllUsers();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        while (resultSet.next()) {
            User user = new User();
            user.setIdNo(resultSet.getLong("userId"));
            user.setFirstName(resultSet.getString("firstName"));
            user.setLastName(resultSet.getString("lastName"));
            user.setUserAge(resultSet.getLong("age"));
            user.setUserWeight(resultSet.getLong("weight"));
            user.setFee(resultSet.getLong("fee"));
            user.setMuscle(resultSet.getString("muscleType"));
            user.setTimeSlot(resultSet.getString("timeSlot"));
            userList.addAll(user);
        }


        id.setCellValueFactory(new PropertyValueFactory<User,Long>("idNo"));
        firstName.setCellValueFactory(new PropertyValueFactory<User,String>("firstName"));
        lastName.setCellValueFactory(new PropertyValueFactory<User,String>("LastName"));
        age.setCellValueFactory(new PropertyValueFactory<User,Long>("userAge"));
        weight.setCellValueFactory(new PropertyValueFactory<User,Long>("userWeight"));
        fee.setCellValueFactory(new PropertyValueFactory<User,Long>("fee"));
        muscle.setCellValueFactory(new PropertyValueFactory<User,Long>("muscle"));
        timeSlot.setCellValueFactory(new PropertyValueFactory<User,String>("timeSlot"));
     //   tableView.setColumnResizePolicy(TreeTableView.CONSTRAINED_RESIZE_POLICY);
        tableview.setItems(userList);
    }


}
