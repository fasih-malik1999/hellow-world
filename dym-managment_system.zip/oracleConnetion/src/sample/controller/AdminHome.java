package sample.controller;

import com.jfoenix.controls.JFXButton;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;

public class AdminHome {

    @FXML
    private JFXButton logout;

    @FXML
    private AnchorPane main_pane;
    private AnchorPane exc;

    @FXML
    void initialize(){


        logout.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {


                Parent parent = null;
                try {
                    parent = FXMLLoader.load(getClass().getResource("/sample/view/login.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Scene scene = new Scene(parent,1200,700);
                Stage stage = (Stage) logout.getScene().getWindow();
                stage.setScene(scene);
                stage.show();

            }
        });
    }
    public void handleButton1Action(javafx.event.ActionEvent actionEvent) throws IOException {
        exc = FXMLLoader.load(getClass().getResource("/sample/view/userScreen.fxml"));
        setNode(exc);
    }

    public void handleButton2Action(javafx.event.ActionEvent actionEvent) throws IOException {
        exc = FXMLLoader.load(getClass().getResource("/sample/view/trainerScreen.fxml"));
        setNode(exc);
    }

    public void handleButton3Action(javafx.event.ActionEvent actionEvent) throws IOException {
        exc = FXMLLoader.load(getClass().getResource("/sample/view/nutriantScreen.fxml"));
        setNode(exc);
    }


    @FXML
   public void handleButton4Action(javafx.event.ActionEvent event) throws IOException {
        exc = FXMLLoader.load(getClass().getResource("/sample/view/equipmentScreen.fxml"));
        setNode(exc);
    }


    public void setNode(Node node)
    {
        main_pane.getChildren().clear();
        main_pane.getChildren().add((Node)node);
//        AnchorPane.setTopAnchor(node,4.0);
//        AnchorPane.setBottomAnchor(node,0.0);
//        AnchorPane.setRightAnchor(node,0.0);
//        AnchorPane.setLeftAnchor(node,0.0);

        FadeTransition ft =new FadeTransition();
        ft.setDuration(Duration.millis(1500));
        ft.setNode(node);
        ft.setFromValue(0.1);
        ft.setToValue(1);
        ft.setAutoReverse(false);
        ft.play();

    }
}
