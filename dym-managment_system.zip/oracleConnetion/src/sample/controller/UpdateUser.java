package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;

public class UpdateUser {

    @FXML
    private JFXTextField firstName;

    @FXML
    private JFXTextField lastname;

    @FXML
    private JFXTextField name;

    @FXML
    private JFXTextField age;

    @FXML
    private JFXTextField weight;

    @FXML
    private JFXPasswordField password;

    @FXML
    public JFXButton updateUser;

    @FXML
    public static JFXTextField idCard;



}
