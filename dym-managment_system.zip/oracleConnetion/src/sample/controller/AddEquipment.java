package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import sample.DBQueries;
import sample.model.Equipment;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.sql.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AddEquipment {
    @FXML
    private ImageView image;

    @FXML
    private JFXTextField id;

    @FXML
    private JFXTextField name;

    @FXML
    private JFXTextField model;

    @FXML
    private JFXTextField cost;

    @FXML
    private JFXDatePicker dop;

    @FXML
    private JFXDatePicker dlm;

    @FXML
    private JFXButton addButton;
    private int eqId;
    private String eqModel , eqName ;
    private long eqCost;
    private Date eqDOP , eqDLM;
    private FileInputStream fis;
    private File file;
    private DBQueries dbQueries;
    private Image img;


    @FXML
    void initialize(){

        image.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                FileChooser fileChooser = new FileChooser();

                //Set extension filter

                FileChooser.ExtensionFilter extFilterjpg =
                        new FileChooser.ExtensionFilter("jpg files (*.jpg)", "*.jpg");
                FileChooser.ExtensionFilter extFilterpng =
                        new FileChooser.ExtensionFilter("png files (*.png)", "*.png");
                fileChooser.getExtensionFilters()
                        .addAll( extFilterjpg, extFilterpng);

                //Show open file dialog
                file = fileChooser.showOpenDialog(null);

                if(file != null){

                    img = new Image(file.toURI().toString(),300,200,true,true);
                    image.setImage(img);
                    image.setFitHeight(200);
                    image.setFitWidth(300);
                    image.setPreserveRatio(true);

                    try {
                        fis = new FileInputStream(file);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }


            }
        });
        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                addEquipment();
            }
        });

    }

    private void addEquipment() {

        eqId = Integer.parseInt(id.getText());
        eqModel = model.getText();
        eqName = name.getText();
        eqCost = Long.parseLong(cost.getText());
        eqDOP = Date.valueOf(dop.getValue());
        eqDLM = Date.valueOf(dlm.getValue());

        Equipment equipment = new Equipment(eqId,eqModel,eqName,eqCost,eqDOP,eqDLM);
        dbQueries = new DBQueries();
        dbQueries.addEquipment(equipment , fis , file);
        addButton.getScene().getWindow().hide();

    }
}
