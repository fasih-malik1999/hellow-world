package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import sample.DBQueries;
import sample.model.Employee;

import java.sql.SQLException;

public class AddNewTrainer {

    @FXML
    private JFXTextField name;

    @FXML
    private JFXTextField qualfication;

    @FXML
    private JFXTextField experience;

    @FXML
    private JFXPasswordField password;

    @FXML
    private JFXTextField lastName;

    @FXML
    private JFXTextField firstname;

    @FXML
    private JFXTextField idCard;

    @FXML
    private JFXButton addButton;

    @FXML
    private RadioButton dayTime;

    @FXML
    private RadioButton nightTime;



    private String fname,lname,nm,exp,qua,pass;
    private long id;
    private DBQueries dbQueries;
    private String s;

    @FXML
    void initialize() throws SQLException {

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
             addTrainer();
            }
        });

        ToggleGroup tg = new ToggleGroup();
        dayTime.setToggleGroup(tg);
        nightTime.setToggleGroup(tg);

        // add a change listener
        tg.selectedToggleProperty().addListener(new ChangeListener<Toggle>()
        {
            public void changed(ObservableValue<? extends Toggle> ob,
                                Toggle o, Toggle n)
            {

                RadioButton rb = (RadioButton)tg.getSelectedToggle();

                if (rb != null) {
                    s = rb.getText();
                    System.out.println(s);
                }
            }
        });
    }
    private void addTrainer(){

        fname = firstname.getText();
        lname = lastName.getText();
        nm = name.getText();
        pass = password.getText();
        exp = experience.getText();
        qua = qualfication.getText();
        id = Long.parseLong(idCard.getText());

        Employee employee = new Employee(nm,pass,exp,qua,fname,lname,id);
        employee.setSlotTime(s);
        dbQueries = new DBQueries();
        dbQueries.signUpEmployee(employee,"Trainer");
        addButton.getScene().getWindow().hide();
    }
}
