package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import sample.DBQueries;
import sample.model.Equipment;
import sample.model.User;

import java.io.*;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.function.Predicate;

public class EquipmentController {

    @FXML
    private TableView<Equipment> table_view;

    @FXML
    private JFXButton deleteButton;

    @FXML
    private JFXButton addButton;

    @FXML
    private TextField search;


    private DBQueries dbQueries;
    private ObservableList<Equipment> equipmentList;
    private FileOutputStream fos;

    @FXML
    void initialize() throws SQLException {

        TableColumn image = new TableColumn("Image");
        TableColumn id = new TableColumn("Id");
        TableColumn name = new TableColumn("Name");
        TableColumn model = new TableColumn("Model");
        TableColumn cast = new TableColumn("cast");
        TableColumn dfp = new TableColumn("Date of purchase");
        TableColumn dlm = new TableColumn("Date of last maintenance");

        image.setPrefWidth(160);
        id.setPrefWidth(90);
        name.setPrefWidth(90);
        model.setPrefWidth(90);
        cast.setPrefWidth(90);
        dfp.setPrefWidth(150);
        dlm.setPrefWidth(200);

        table_view.getColumns().addAll(image,id,name,model,cast,dfp,dlm);
        try {
            setTable(image,id,name,model,cast,dfp,dlm);
        } catch (IOException e) {
            e.printStackTrace();
        }


        FilteredList<Equipment> list = new FilteredList<>(equipmentList);

        search.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                list.setPredicate(new Predicate<Equipment>() {
                    @Override
                    public boolean test(Equipment equipment) {
                        if(newValue == null || newValue.isEmpty()){
                            return true;
                        }

                        String lower = newValue.toLowerCase();
                        if(equipment.getModel().toLowerCase().indexOf(lower) != -1){
                            return true;
                        }
                        else
                            return false;
                    }
                });
            }
        });
        table_view.setItems(list);

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                addButton.getScene().getWindow();

                FXMLLoader loader = new FXMLLoader();

                loader.setLocation(getClass().getResource("/sample/view/addEquipment.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.showAndWait();

                try {
                    setTable(image,id,name,model,cast,dfp,dlm);
                } catch (SQLException | IOException e) {
                    e.printStackTrace();
                }

            }
        });
        deleteButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                long idd = table_view.getSelectionModel().getSelectedItem().getId();
                try {
                    dbQueries.deleteEqu(idd);
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }

                try {
                    setTable(image,id,name,model,cast,dfp,dlm);
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                // table_view.refresh();
            }
        });

    }

    public void setTable(TableColumn image,TableColumn id,TableColumn name,TableColumn model, TableColumn cast,TableColumn dfp,TableColumn dlm) throws SQLException, IOException {

        dbQueries = new DBQueries();
        equipmentList = FXCollections.observableArrayList();
        ResultSet resultSet = null;
        try {
            resultSet = dbQueries.getEquipment();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        while (resultSet.next()) {
            Equipment equipment = new Equipment();
            equipment.setId(resultSet.getInt("equId"));
            equipment.setName(resultSet.getString("equName"));
            equipment.setModel(resultSet.getString("equModel"));
            equipment.setCost(resultSet.getLong("equCast"));
            equipment.setDateOfPurchase(resultSet.getDate("dateOfPurchase"));
            equipment.setLastMaintenance(resultSet.getDate("dateOfMaintance"));

            File file =new File("photo.jpg");
            try {
                fos = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            byte b[];
            Blob blob;

            blob = resultSet.getBlob("image");
            System.out.println(blob);
            b = blob.getBytes(1,(int)blob.length());
            fos.write(b);

            ImageView imageView = new ImageView(new Image("file:photo.jpg",150,200,true,true));
            imageView.setFitHeight(200);
            imageView.setFitWidth(150);
            imageView.setPreserveRatio(true);
            equipment.setImage(imageView);

            equipmentList.addAll(equipment);
        }

        image.setCellValueFactory(new PropertyValueFactory<Equipment, ImageView>("image"));
        id.setCellValueFactory(new PropertyValueFactory<Equipment,Long>("id"));
        name.setCellValueFactory(new PropertyValueFactory<Equipment,String>("name"));
        model.setCellValueFactory(new PropertyValueFactory<Equipment,String>("model"));
        cast.setCellValueFactory(new PropertyValueFactory<Equipment,Long>("cost"));
        dfp.setCellValueFactory(new PropertyValueFactory<Equipment, Date>("dateOfPurchase"));
        dlm.setCellValueFactory(new PropertyValueFactory<Equipment,Date>("lastMaintenance"));

        table_view.setItems(equipmentList);
    }
}
