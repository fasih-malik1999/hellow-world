package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTreeTableView;
import com.jfoenix.controls.RecursiveTreeItem;
import com.jfoenix.controls.datamodels.treetable.RecursiveTreeObject;
import com.sun.xml.internal.ws.message.EmptyMessageImpl;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TreeItemPropertyValueFactory;
import javafx.stage.Stage;
import sample.DBQueries;
import sample.model.Employee;
import sample.model.User;
import sample.usersController.UserProfile;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.function.Predicate;

public class TrainerScreen {

    @FXML
    private TableView<Employee> table_view;

    @FXML
    private JFXButton deleteButton;

    @FXML
    private JFXButton updateButton;

    @FXML
    private JFXButton addButton;

    @FXML
    private TextField search;
    private DBQueries dbQueries;
    private ObservableList<Employee> employeesList;
    private Employee employee;
    private String password,name;

    @FXML
    void initialize() throws SQLException {

        TableColumn id = new TableColumn("TrainerId");
        TableColumn firstName = new TableColumn("FirstName");
        TableColumn lastName = new TableColumn("LastName");
        TableColumn qualification = new TableColumn("Qualification");
        TableColumn experience = new TableColumn("Experience");
        TableColumn timeSlot = new TableColumn("TimeSlot");

        id.setPrefWidth(140);
        firstName.setPrefWidth(140);
        lastName.setPrefWidth(140);
        qualification.setPrefWidth(140);
        experience.setPrefWidth(140);
        timeSlot.setPrefWidth(140);

        table_view.getColumns().addAll(id,firstName,lastName,qualification,experience,timeSlot);
        setTable(id,firstName,lastName,qualification,experience,timeSlot);


        FilteredList<Employee> employ = new FilteredList<>(employeesList);
        search.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                employ.setPredicate(new Predicate<Employee>() {
                    @Override
                    public boolean test(Employee employee) {
                        if(newValue == null || newValue.isEmpty()){
                            return true;
                        }

                        String lower = newValue.toLowerCase();
                        if(employee.getFirstName().toLowerCase().indexOf(lower) != -1){
                            return true;
                        }else if(employee.getLastName().toLowerCase().indexOf(lower) != -1){
                            return true;
                        }
                        else
                            return false;
                    }
                });
            }
        });
        table_view.setItems(employ);

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                addButton.getScene().getWindow();

                FXMLLoader loader = new FXMLLoader();

                loader.setLocation(getClass().getResource("/sample/view/addNewTrainer.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.showAndWait();

                try {
                    setTable(id,firstName,lastName,qualification,experience,timeSlot);
                } catch (SQLException e) {
                    e.printStackTrace();
                }


            }
        });
        updateButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                long idd = table_view.getSelectionModel().getSelectedItem().getIdNo();
                dbQueries = new DBQueries();
                ResultSet resultSet = dbQueries.getTrainer(idd);
                System.out.println(idd);

                while(true){
                    try {
                        if (!resultSet.next())
                            break;
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                   employee = new Employee();
                    try {
                        employee.setIdNo(resultSet.getLong("trainerId"));
                        employee.setFirstName(resultSet.getString("firstName"));
                        employee.setLastName(resultSet.getString("lastName"));
                        employee.setQualification(resultSet.getString("qualification"));
                        employee.setExperience(resultSet.getString("experience"));
                        employee.setSlotTime(resultSet.getString("timeSlot"));
                        password = resultSet.getString("userPassword");
                        name = resultSet.getString("userName");

                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }

                updateButton.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/sample/view/updateTrainer.fxml"));

                try {
                    loader.load();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Parent root = loader.getRoot();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));

                UpdateTrainer updateTrainer = loader.getController();

                updateTrainer.setIdCard(employee.getIdNo());
                updateTrainer.setFirstname(employee.getFirstName());
                updateTrainer.setLastName(employee.getLastName());
                updateTrainer.setExperience(employee.getExperience());
                updateTrainer.setQualfication(employee.getQualification());
                updateTrainer.setTimeSlot(employee.getSlotTime());

                updateTrainer.updateButton.setOnAction(event1 -> {

                    try {
                        dbQueries.updateEmployee(updateTrainer.getIdCard(),
                                updateTrainer.getFirstname(),
                                updateTrainer.getLastName(),
                                name,password,
                                updateTrainer.getQualfication(),updateTrainer.getExperience()
                        ,updateTrainer.getTimeSlot());
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                    try {
                        setTable(id,firstName,lastName,qualification,experience,timeSlot);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }

                    updateTrainer.updateButton.getScene().getWindow().hide();

                });

                stage.showAndWait();


            }
        });
        deleteButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

               // table_view.getItems().remove(table_view.getSelectionModel().getSelectedItem());
                long idd = table_view.getSelectionModel().getSelectedItem().getIdNo();
                System.out.println(idd);
                try {
                    dbQueries.deleteTrainer(idd);
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }

                try {
                    setTable(id,firstName,lastName,qualification,experience,timeSlot);
                } catch (SQLException e) {
                    e.printStackTrace();
                }


                //table_view.refresh();
            }
        });

    }

    public void setTable(TableColumn id,TableColumn firstName,TableColumn lastName,TableColumn qualfication , TableColumn experience,TableColumn timeSlot) throws SQLException{


        dbQueries = new DBQueries();
        employeesList = FXCollections.observableArrayList();
        ResultSet resultSet = null;
        try {
            resultSet = dbQueries.getAllTrainers();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        while (resultSet.next()) {
            Employee employee = new Employee();
            employee.setIdNo(resultSet.getLong("trainerId"));
            employee.setFirstName(resultSet.getString("firstName"));
            employee.setLastName(resultSet.getString("lastName"));
            employee.setQualification(resultSet.getString("qualification"));
            employee.setExperience(resultSet.getString("experience"));
            employee.setSlotTime(resultSet.getString("timeSlot"));

            employeesList.addAll(employee);
        }


        id.setCellValueFactory(new PropertyValueFactory<Employee,Long>("idNo"));
        firstName.setCellValueFactory(new PropertyValueFactory<EmptyMessageImpl,String>("firstName"));
        lastName.setCellValueFactory(new PropertyValueFactory<Employee,String>("lastName"));
        qualfication.setCellValueFactory(new PropertyValueFactory<Employee,String>("qualification"));
        experience.setCellValueFactory(new PropertyValueFactory<Employee,String>("experience"));
        timeSlot.setCellValueFactory(new PropertyValueFactory<Employee,String>("slotTime"));
        table_view.setItems(employeesList);

    }

}
