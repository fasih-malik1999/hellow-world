package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import sample.DBQueries;
import sample.animations.Shaker;
import sample.model.Employee;
import sample.model.User;
import sun.plugin.javascript.navig.Anchor;

import java.awt.*;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class LoginController{

    public static long trainerId;
    public static String timeSlot;
    public static long nutriantId;
    public static long userId;
    @FXML
    private JFXTextField name;

    @FXML
    private JFXButton login;

    @FXML
    private Label signUp;

    @FXML
    private AnchorPane mainPane;


    @FXML
    private JFXComboBox<?> comBox;

    @FXML
    private JFXPasswordField password;

    private DialogPane pane;
    private DBQueries dbQueries;
    private String value;
    String str ;

    @FXML
    void initialize(){

//        mainPane.widthProperty().addListener(new ChangeListener<Number>() {
//            @Override
//            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
//                if(mainPane.getWidth() > 1200){
//                    AnchorPane.setRightAnchor(logi,500.0);
//                    AnchorPane.setLeftAnchor(logi,800.0);
//                    AnchorPane.setTopAnchor(logi,88.0);
//                    AnchorPane.setTopAnchor(name,147.0);
//                    AnchorPane.setLeftAnchor(name,750.0);
//                  //  AnchorPane.setRightAnchor(name,500.0);
//                }else{
//                    AnchorPane.setRightAnchor(logi,635.0);
//                    AnchorPane.setLeftAnchor(logi,505.0);
//                    AnchorPane.setTopAnchor(logi,88.0);
//                    AnchorPane.setTopAnchor(name,147.0);
//                    AnchorPane.setLeftAnchor(name,430.0);
//                  //  AnchorPane.setRightAnchor(name,560.0);
//                }
//            }
//        });



        comBox.getSelectionModel().selectFirst();

        login.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
               value = comBox.getValue().toString();
                System.out.println(value);
                System.out.println("login clicked");

                dbQueries = new DBQueries();
                String loginText = name.getText().trim();
                String loginPwd = password.getText().trim();

                Employee employee = new Employee();
                employee.setName(loginText);
                employee.setPassword(loginPwd);

                User user = new User();
                user.setName(loginText);
                user.setPassword(loginPwd);

                ResultSet userRow=null;

                if(value.equals("User")){
                    userRow = dbQueries.getUser(user);
                }else if(value.equals("Trainer")){
                    userRow = dbQueries.getEmployee(employee, value);
                }else if(value.equals("Admin")){
                    userRow = dbQueries.getEmployee(employee, value);
                }else if(value.equals("Nutriant")){
                    userRow = dbQueries.getEmployee(employee, value);
                }

                int counter = 0;

                try {
                    while (userRow.next()) {
                        counter++;
                        String name = userRow.getString("firstName");
                       if(value.equals("Trainer")){
                            trainerId = userRow.getInt("trainerId");
                            timeSlot = userRow.getString("timeSlot");
                        }else if(value.equals("Nutriant")){
                           nutriantId = userRow.getInt("nutriantId");
                           timeSlot = userRow.getString("timeSlot");
                       }else if(value.equals("User")){
                           userId = userRow.getInt("userId");
                       }
                        System.out.println("Welcome! " + name);
                    }

                    if (counter == 1) {

                        showAddItemScreen();

                    }else {
                        Shaker userNameShaker = new Shaker(name);
                        Shaker passwordShaker = new Shaker(password);
                        passwordShaker.shake();
                        userNameShaker.shake();
                        System.out.println("error");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }
        });


        signUp.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                System.out.println("signup");


                final Stage dialog = new Stage();
                dialog.initModality(Modality.APPLICATION_MODAL);
                //dialog.initOwner(primaryStage);
                HBox dialogVbox = new HBox(20);
                Button user = new Button("User");
                Button employee = new Button("Employee");
                dialogVbox.getChildren().add(user);
                dialogVbox.getChildren().add(employee);
                dialog.setTitle("Select one of them");
                dialogVbox.setMargin(user,new Insets(16,16,16,16));
                dialogVbox.setMargin(employee,new Insets(16,16,16,16));
                Scene dialogScene = new Scene(dialogVbox, 350, 100);
                dialog.setScene(dialogScene);
                dialog.show();

                user.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {

                        //Take users to signup screen
                        user.getScene().getWindow().hide();

                        FXMLLoader loader = new FXMLLoader();

                        loader.setLocation(getClass().getResource("/sample/view/userSignUp.fxml"));

                        try {
                            loader.load();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        System.out.println("user");
                        Parent root = loader.getRoot();
                        Stage stage = new Stage();
                        stage.setScene(new Scene(root));
                        stage.showAndWait();
                        //dialog.close();
                    }
                });
                employee.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        System.out.println("employee");

                        //Take users to signup screen
                        employee.getScene().getWindow().hide();

                        FXMLLoader loader = new FXMLLoader();

                        loader.setLocation(getClass().getResource("/sample/view/employeeSignUp.fxml"));

                        try {
                            loader.load();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        Parent root = loader.getRoot();
                        Stage stage = new Stage();
                        Scene scene = new Scene(root);
                        stage.setScene(scene);
                        stage.showAndWait();

                        dialog.close();
                    }
                });

            }
        });

    }

    private void showAddItemScreen() {
        //Take users to signup screen
        login.getScene().getWindow().hide();

        FXMLLoader loader = new FXMLLoader();
        if(value.equals("Trainer"))
        {
            str = "trainerHome";
        }else if(value.equals("Admin")){
            str ="adminhome";
        }else if(value.equals("Nutriant")){
            str = "nutriantHome";
        }else if(value.equals("User")){
            str = "userHome";
        }

        loader.setLocation(getClass().getResource("/sample/view/"+str+".fxml"));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.showAndWait();

    }


}
