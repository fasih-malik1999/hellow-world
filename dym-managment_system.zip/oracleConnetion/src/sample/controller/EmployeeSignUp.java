package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import sample.DBQueries;
import sample.model.Employee;

public class EmployeeSignUp {

    @FXML
    private JFXTextField name;

    @FXML
    private JFXTextField qualfication;

    @FXML
    private JFXTextField experience;

    @FXML
    private JFXPasswordField password;

    @FXML
    private JFXButton signUp;

    @FXML
    private JFXTextField lastName;

    @FXML
    private JFXTextField firstname;

    @FXML
    private JFXComboBox<?> comBox;

    @FXML
    private JFXTextField idCard;
    @FXML
    private Label timeLabel;

    @FXML
    private RadioButton dayTime;

    @FXML
    private RadioButton nightTime;

    private String nm , pas,exp , qua,fnm,lnm;
    private long idNo;
    private DBQueries dbHandler;
    private   String value , s;

    @FXML
    void initialize(){

        comBox.getSelectionModel().selectFirst();


        signUp.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                signUp();
            }
        });


    }

    private void signUp() {

        dbHandler = new DBQueries();

        idNo =Long.parseLong(idCard.getText());
        fnm = firstname.getText().toString();
        lnm = lastName.getText().toString();
        nm = name.getText().toString();
        pas = password.getText().toString();
        exp = experience.getText().toString();
        qua = qualfication.getText().toString();

        Employee employee = new Employee(nm,pas,exp,qua,fnm,lnm,idNo);
        employee.setSlotTime(s);
        dbHandler.signUpEmployee(employee,value);
        signUp.getScene().getWindow().hide();
    }


    public void comboSelection(ActionEvent actionEvent) {
        value = comBox.getValue().toString();
        System.out.println(value);

        if(value.equals("Trainer") || value.equals("Nutriant") ){
            timeLabel.setVisible(true);
            dayTime.setVisible(true);
            nightTime.setVisible(true);

            selectTimeSlot();
        }else{
            timeLabel.setVisible(false);
            dayTime.setVisible(false);
            nightTime.setVisible(false);
        }

    }

    private void selectTimeSlot() {
        ToggleGroup tg = new ToggleGroup();
        dayTime.setToggleGroup(tg);
        nightTime.setToggleGroup(tg);

        // add a change listener
        tg.selectedToggleProperty().addListener(new ChangeListener<Toggle>()
        {
            public void changed(ObservableValue<? extends Toggle> ob,
                                Toggle o, Toggle n)
            {

                RadioButton rb = (RadioButton)tg.getSelectedToggle();

                if (rb != null) {
                    s = rb.getText();
                    System.out.println(s);
                }
            }
        });
    }
}
