package sample.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;

public class UpdateTrainer {

    @FXML
    private JFXTextField timeSlot;

    @FXML
    private JFXTextField qualfication;

    @FXML
    private JFXTextField experience;


    @FXML
    public JFXButton updateButton;

    @FXML
    private JFXTextField lastName;

    @FXML
    private JFXTextField firstname;

    @FXML
    private JFXTextField idCard;

    @FXML
    public JFXTextField userName;

    public String getUserName() {
        return userName.getText();
    }

    public void setUserName(String userName) {
        this.userName.setText(userName);
    }

    public String getPassword() {
        return password.getText();
    }

    public void setPassword(String password) {
        this.password.setText(password);
    }

    @FXML
    public JFXTextField password;


    public String getQualfication() {
        return this.qualfication.getText();
    }

    public void setQualfication(String qualfication) {
        this.qualfication.setText(qualfication);
    }

    public String getExperience() {
        return experience.getText();
    }

    public void setExperience(String experience) {
        this.experience.setText(experience);
    }

    public String getTimeSlot() {
        return timeSlot.getText();
    }

    public void setTimeSlot(String timeSlot) {
        this.timeSlot.setText(timeSlot);
    }

    public String getLastName() {
        return lastName.getText();
    }

    public void setLastName(String lastName) {
        this.lastName.setText(lastName);
    }

    public String getFirstname() {
        return firstname.getText();
    }

    public void setFirstname(String firstname) {
        this.firstname.setText(firstname);
    }

    public long getIdCard() {
        return Long.parseLong(idCard.getText());
    }

    public void setIdCard(long idCard) {
        this.idCard.setText(String.valueOf(idCard));
    }
}
