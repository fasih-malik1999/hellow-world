Image = imread('3.jpg');
figure, imshow(Image); title('Brain MRI Image');
Image = imresize(Image,[200,200]);
Image = rgb2gray(Image);
Image = im2bw(Image,.6);
figure, imshow(Image);title('Thresholded Image');
filter = fspecial('sobel');
filtered = filter';
filter_apply = imfilter(double(Image), filter, 'replicate');
replicate_filter = imfilter(double(Image), filtered, 'replicate');
wshed = sqrt(replicate_filter.^2 + filter_apply.^2);
apply_wshed = watershed(wshed);
for_rgb = label2rgb(apply_wshed);
figure, imshow(for_rgb), title('Watershed segmented image ')
disk = strel('disk', 5);
open_disk = imopen(Image, disk);
rode_disk = imerode(Image, disk);
recons_disk_image = imreconstruct(rode_disk, Image);
Iobrd = imdilate(recons_disk_image, disk);
Iobrcbr = imreconstruct(imcomplement(Iobrd), imcomplement(recons_disk_image));
Iobrcbr = imcomplement(Iobrcbr);
Image2 = Image;
regional = imregionalmax(Iobrcbr);
Image2(regional) = 255;
strel_image = strel(ones(5,5));
reg2 = imclose(regional, strel_image);
reg3 = imerode(reg2, strel_image);
reg4 = bwareaopen(reg3, 20);
Image3 = Image;
bw = im2bw(Iobrcbr);
figure
imshow(bw), title('Only Tumor')